<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['scf_02']?></label> <small style="float:right"><?=$lang['scf_01']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>