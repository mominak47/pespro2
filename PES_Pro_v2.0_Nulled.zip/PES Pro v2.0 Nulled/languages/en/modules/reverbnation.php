<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['reverbnation_01'] = 'Reverbnation account already added!';
$lang['reverbnation_02'] = '<b>ERROR:</b> This ReverbNation account is not valid or doesn\'t exists!';
$lang['reverbnation_03'] = 'Reverbnation account was successfully added!';
$lang['reverbnation_04'] = 'http://www.reverbnation.com/fan/USERNAME';
$lang['reverbnation_05'] = 'Fan';
$lang['reverbnation_06'] = '<b>ERROR:</b> This Reverbnation account doesn\'t exists!';
$lang['reverbnation_07'] = 'skip';
$lang['reverbnation_08'] = 'SUCCESS! You skipped this account!';
$lang['reverbnation_09'] = 'Become a fan and close opened window...';
$lang['reverbnation_10'] = 'We cannot contact Reverbnation...';
$lang['reverbnation_11'] = 'Reverbnation says that you are not a fan!';
$lang['reverbnation_12'] = 'SUCCESS!';
$lang['reverbnation_13'] = ' coins were added to your account!';
$lang['reverbnation_14'] = 'Reverbnation account';
$lang['reverbnation_15'] = 'In order to "Become a Fan" of others pages you must have a ReverbNation Account connected. You have to attach your Reverbnation FAN account, not an artist account.';
$lang['reverbnation_16'] = '<b>ERROR:</b> URL must be something like:';

// Add Page
$lang['reverbnation_url'] = 'Page URL';
$lang['reverbnation_title'] = 'Page Title';
$lang['reverbnation_url_desc'] = 'Add your reverbnation account url here';
$lang['reverbnation_title_desc'] = 'Add your reverbnation title here';
?>