<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['yt_01'] = 'Video already added!';
$lang['yt_02'] = 'Please enter a valid Youtube link!';
$lang['yt_03'] = 'Video added successfully!';
$lang['yt_04'] = 'Watch this video for at least -TIME- seconds and after that you will receive -COINS-';
$lang['yt_05'] = 'Must play for -TIME- seconds';
$lang['yt_06'] = 'Skip';
$lang['yt_07'] = 'Click here to watch other movie';
$lang['yt_08'] = 'Watch Video';
$lang['yt_09'] = '';

// Add Page
$lang['yt_url'] = 'Video URL';
$lang['yt_title'] = 'Video Title';
$lang['yt_url_desc'] = 'Add your video url here';
$lang['yt_title_desc'] = 'Add your video title here';
?>