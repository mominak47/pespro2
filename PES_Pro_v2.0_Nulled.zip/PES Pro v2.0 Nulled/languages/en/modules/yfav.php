<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['yfav_01'] = 'Video already added!';
$lang['yfav_02'] = 'Please enter a valid Youtube link!';
$lang['yfav_03'] = 'Video added successfully!';
$lang['yfav_04'] = 'YouTube Username';
$lang['yfav_05'] = 'Favorite';
$lang['yfav_06'] = '<b>ERROR:</b> This Youtube account doesn\'t exists!';
$lang['yfav_07'] = 'skip';
$lang['yfav_08'] = 'SUCCESS! You skipped this video!';
$lang['yfav_09'] = 'Add video to favourites and close opened window...';
$lang['yfav_10'] = 'We cannot contact Youtube...';
$lang['yfav_11'] = 'Youtube says you haven\'t added this video to favourites!';
$lang['yfav_12'] = 'SUCCESS!';
$lang['yfav_13'] = ' coins were added to your account!';
$lang['yfav_14'] = 'YouTube account';
$lang['yfav_15'] = 'You have to attach your YouTube profile in order to be able to earn coins by adding to favorites other\'s videos. Attached account must be the same account used to add videos to favorites.';

// Add Page
$lang['yfav_url'] = 'Video URL';
$lang['yfav_title'] = 'Video Title';
$lang['yfav_url_desc'] = 'Add your video url here';
$lang['yfav_title_desc'] = 'Add your video title here';
?>